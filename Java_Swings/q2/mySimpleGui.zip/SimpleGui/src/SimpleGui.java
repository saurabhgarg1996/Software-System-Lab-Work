import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class SimpleGui {
	private JFrame mainFrame;
	private JLabel headerLabel;
	private JLabel statusLabel;
	private JPanel controlPanel;
	private JButton Red = new JButton("Red");
	private JButton Blue = new JButton("Blue");
	private JButton Yellow = new JButton("Yellow");
	private JButton Close  = new JButton("Close");
	private JFrame frame = new JFrame("Message");
	private JFrame intro = new JFrame("Input");
	private String name;

	public SimpleGui(){
		prepareGUI();
	}

	public static void main(String[] args){
		SimpleGui bg = new SimpleGui();
		bg.AddButtons();
	}

	private void prepareGUI(){
		
		
		mainFrame = new JFrame("Java SWING Examples");
		mainFrame.setSize(400,400);
		mainFrame.setVisible(true);
		//intro.setLocation(10, 100);
		name = (String)JOptionPane.showInputDialog(intro, "What is your name?");
		//intro.setVisible(true);
		if (name == null)
			System.exit(0);
		
		mainFrame.setLayout(new GridLayout(3, 1));
		headerLabel = new JLabel("",JLabel.CENTER);
		statusLabel = new JLabel("",JLabel.CENTER);
		controlPanel = new JPanel();
		controlPanel.setLayout(new FlowLayout());
		statusLabel.setSize(350,100);
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}        
		});    

		
		headerLabel.setText("What is your favourite color?"); 
		mainFrame.add(headerLabel);
		mainFrame.add(controlPanel);
		mainFrame.add(statusLabel);
		
		
		mainFrame.setVisible(true);  
	}
	
	public void AddButtons(){
		
		Red.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Hey "+ name+"!! It seems your favourite color is Red!! :P");	
			}
			
		});
		
		Blue.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Hey "+ name+"!! It seems your favourite color is Blue!! :P");	
			}
			
		});
		
		Yellow.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Hey "+ name+"!! It seems your favourite color is Yellow!! :P");	
			}
			
		});
		
		Close.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Hey "+ name +"!! Good Bye!!");
				System.exit(0);	
			}
			
		});
		
		controlPanel.add(Red);
		controlPanel.add(Blue);
		controlPanel.add(Yellow);
		controlPanel.add(Close);
		mainFrame.setVisible(true);
	}
}
